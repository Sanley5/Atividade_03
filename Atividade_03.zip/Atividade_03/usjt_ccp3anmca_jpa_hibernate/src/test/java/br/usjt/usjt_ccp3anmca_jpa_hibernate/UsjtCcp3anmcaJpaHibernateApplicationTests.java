package br.usjt.usjt_ccp3anmca_jpa_hibernate;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UsjtCcp3anmcaJpaHibernateApplicationTests {

	@Test
	void contextLoads() {
	}

}
